package com.example.chestbuttons.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

/**
 * Envanter/sandik ekranina "Her Seyi Al" ve "Her Seyi At" butonlari ekler.
 * Mixin kullanmaz: Fabric Screen API uzerinden calisir, bu yuzden
 * surumler arasi intermediary isimlerine bagli degildir.
 */
public class ChestButtonsClient implements ClientModInitializer {

    private static final int BUTTON_WIDTH = 80;
    private static final int BUTTON_HEIGHT = 20;
    private static final int GAP = 4;

    @Override
    public void onInitializeClient() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (!(screen instanceof HandledScreen<?> handled)) {
                return;
            }

            int x = handled.x + handled.backgroundWidth + GAP;
            int y = handled.y + 4;

            ButtonWidget takeAll = ButtonWidget.builder(Text.literal("Her Şeyi Al"),
                    button -> takeAll(client, handled.getScreenHandler()))
                    .dimensions(x, y, BUTTON_WIDTH, BUTTON_HEIGHT)
                    .build();

            ButtonWidget dropAll = ButtonWidget.builder(Text.literal("Her Şeyi At"),
                    button -> dropAll(client, handled.getScreenHandler()))
                    .dimensions(x, y + BUTTON_HEIGHT + GAP, BUTTON_WIDTH, BUTTON_HEIGHT)
                    .build();

            Screens.getButtons(screen).add(takeAll);
            Screens.getButtons(screen).add(dropAll);
        });
    }

    /** Sandiktaki (oyuncu envanteri disindaki) tum esyalari envantere tasir. */
    private static void takeAll(MinecraftClient client, ScreenHandler handler) {
        if (client.player == null || client.interactionManager == null) return;
        for (Slot slot : handler.slots) {
            if (isContainerSlot(client, slot) && slot.hasStack()) {
                client.interactionManager.clickSlot(handler.syncId, slot.id, 0,
                        SlotActionType.QUICK_MOVE, client.player);
            }
        }
    }

    /** Sandiktaki tum esyalari yere atar (button 1 = tum yigin). */
    private static void dropAll(MinecraftClient client, ScreenHandler handler) {
        if (client.player == null || client.interactionManager == null) return;
        for (Slot slot : handler.slots) {
            if (isContainerSlot(client, slot) && slot.hasStack()) {
                client.interactionManager.clickSlot(handler.syncId, slot.id, 1,
                        SlotActionType.THROW, client.player);
            }
        }
    }

    private static boolean isContainerSlot(MinecraftClient client, Slot slot) {
        return slot.inventory != client.player.getInventory();
    }
}
